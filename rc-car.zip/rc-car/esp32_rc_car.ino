// ESP32 + L298N รถ 4 ล้อ (ซ้าย 2 / ขวา 2 ขนานกัน) — ควบคุมผ่าน BLE (Nordic UART)
// ESP32 core 2.x และ 3.x ใช้ได้
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>

#define ENA 25
#define IN1 26
#define IN2 27
#define IN3 14
#define IN4 32
#define ENB 33

#define SVC "6E400001-B5A3-F393-E0A9-E50E24DCCA9E"
#define RXC "6E400002-B5A3-F393-E0A9-E50E24DCCA9E"

const int MIN_DUTY = 90;          // ต่ำกว่านี้มอเตอร์ไม่หมุน — ปรับได้
unsigned long lastCmd = 0;
String buf;

void pwmInit(int pin) {
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcAttach(pin, 1000, 8);
#else
  static int ch = 0; ledcSetup(ch, 1000, 8); ledcAttachPin(pin, ch); ch++;
#endif
}
void pwmWrite(int pin, int duty) {
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcWrite(pin, duty);
#else
  ledcWrite(pin == ENA ? 0 : 1, duty);
#endif
}
int toDuty(int v) { v = abs(v); return v == 0 ? 0 : map(constrain(v, 1, 255), 1, 255, MIN_DUTY, 255); }

void drive(int l, int r) {         // -255..255
  digitalWrite(IN1, l > 0); digitalWrite(IN2, l < 0);
  digitalWrite(IN3, r > 0); digitalWrite(IN4, r < 0);
  pwmWrite(ENA, toDuty(l)); pwmWrite(ENB, toDuty(r));
}

class Rx : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic *c) {
    auto v = c->getValue();
    for (char ch : v) {
      if (ch == '\n') {
        int a, b;
        if (sscanf(buf.c_str(), "M,%d,%d", &a, &b) == 2) {
          drive(constrain(a, -255, 255), constrain(b, -255, 255));
          lastCmd = millis();
        }
        buf = "";
      } else buf += ch;
    }
  }
};
class Srv : public BLEServerCallbacks {
  void onConnect(BLEServer *s) { lastCmd = millis(); }
  void onDisconnect(BLEServer *s) { drive(0, 0); BLEDevice::startAdvertising(); }
};

void setup() {
  pinMode(IN1, OUTPUT); pinMode(IN2, OUTPUT); pinMode(IN3, OUTPUT); pinMode(IN4, OUTPUT);
  pwmInit(ENA); pwmInit(ENB); drive(0, 0);

  BLEDevice::init("ESP32-RC-CAR");
  BLEServer *srv = BLEDevice::createServer();
  srv->setCallbacks(new Srv());
  BLEService *svc = srv->createService(SVC);
  BLECharacteristic *rx = svc->createCharacteristic(RXC, BLECharacteristic::PROPERTY_WRITE | BLECharacteristic::PROPERTY_WRITE_NR);
  rx->setCallbacks(new Rx());
  svc->start();
  BLEAdvertising *adv = BLEDevice::getAdvertising();
  adv->addServiceUUID(SVC);
  adv->setScanResponse(true);
  BLEDevice::startAdvertising();
}

void loop() {
  if (millis() - lastCmd > 500) drive(0, 0);   // Failsafe: สัญญาณขาด = หยุดรถ
  delay(20);
}
